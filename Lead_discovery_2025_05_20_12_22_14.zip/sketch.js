

let estado = "campo"; // Começa no campo

function setup() {

  createCanvas(600, 400);

}

function draw() {

  background(220);

  if (estado === "campo") {

    drawCampo();

  } else if (estado === "cidade") {

    drawCidade();

  }

  // Botão para mudar o estado

  fill(150);

  rect(width - 100, height - 40, 80, 30);

  fill(0);

  textAlign(CENTER, CENTER);

  text("Mudar", width - 60, height - 25);

}

function mouseClicked() {

  // Verifica se o clique foi no botão de mudar

  if (mouseX > width - 100 && mouseX < width - 20 && mouseY > height - 40 && mouseY < height - 10) {

    if (estado === "campo") {

      estado = "cidade";

    } else {

      estado = "campo";

    }

  }

}

function drawCampo() {

  // Céu azul

  fill(135, 206, 235);

  rect(0, 0, width, height * 0.6);

  // Grama verde

  fill(34, 139, 34);

  rect(0, height * 0.6, width, height * 0.4);

  // Sol amarelo

  fill(255, 255, 0);

  ellipse(50, 50, 60, 60);

  // Montanhas ao longe (triângulos marrons)

  fill(139, 69, 19);

  triangle(100, height * 0.6, 150, height * 0.4, 200, height * 0.6);

  triangle(250, height * 0.6, 300, height * 0.3, 350, height * 0.6);

  // Árvores verdes (círculos e retângulos)

  fill(0, 100, 0);

  ellipse(450, height * 0.5, 50, 50);

  rect(435, height * 0.5, 30, 80);

  ellipse(550, height * 0.55, 40, 40);

  rect(535, height * 0.55, 30, 70);

  // Uma casa simples (retângulos e triângulo)

  fill(210, 180, 140);

  rect(100, height * 0.6 - 50, 80, 50);

  fill(160, 82, 45);

  triangle(100, height * 0.6 - 50, 140, height * 0.6 - 80, 180, height * 0.6 - 50);

}

function drawCidade() {

  // Céu cinza claro

  fill(200);

  rect(0, 0, width, height * 0.6);

  // Asfalto cinza escuro

  fill(80);

  rect(0, height * 0.6, width, height * 0.4);

  // Prédios (retângulos de várias cores e alturas)

  fill(100);

  rect(50, height * 0.6 - 80, 40, 80);

  fill(150);

  rect(120, height * 0.6 - 120, 60, 120);

  fill(120);

  rect(200, height * 0.6 - 60, 50, 60);

  fill(180);

  rect(280, height * 0.6 - 150, 70, 150);

  fill(140);

  rect(370, height * 0.6 - 90, 45, 90);

  fill(110);

  rect(440, height * 0.6 - 70, 55, 70);

  fill(160);

  rect(520, height * 0.6 - 110, 65, 110);

  // Janelas nos prédios (pequenos retângulos amarelos)

  fill(255, 255, 0);

  for (let i = 55; i < height * 0.6 - 10; i += 20) {

    rect(55, i, 10, 15);

  }

  for (let i = 125; i < height * 0.6 - 10; i += 25) {

    rect(125, i, 15, 20);

    rect(165, i, 15, 20);

  }

  for (let i = 205; i < height * 0.6 - 10; i += 15) {

    rect(205, i, 12, 10);

    rect(235, i, 12, 10);

  }

  for (let i = 285; i < height * 0.6 - 10; i += 30) {

    rect(285, i, 18, 25);

    rect(325, i, 18, 25);

  }

  for (let i = 375; i < height * 0.6 - 10; i += 20) {

    rect(375, i, 10, 15);

    rect(405, i, 10, 15);

  }

  for (let i = 445; i < height * 0.6 - 10; i += 18) {

    rect(445, i, 13, 12);

    rect(475, i, 13, 12);

    rect(505, i, 13, 12);

  }

  for (let i = 525; i < height * 0.6 - 10; i += 22) {

    rect(525, i, 16, 18);

    rect(565, i, 16, 18);

  }

  // Uma estrada (retângulo cinza mais claro)

  fill(105);

  rect(0, height * 0.75, width, 50);

  // Linhas da estrada (retângulos amarelos tracejados)

  fill(255, 255, 0);

  for (let i = 10; i < width; i += 40) {

    rect(i, height * 0.75 + 20, 20, 10);

  }

}